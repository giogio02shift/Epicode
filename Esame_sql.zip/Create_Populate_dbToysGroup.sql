CREATE DATABASE IF NOT exists ToysGroup;
CREATE TABLE categoria(
Id_Categoria INT auto_increment PRIMARY KEY
, NomeCategoria VARCHAR(25));
CREATE TABLE product(
Id_Prodotto INT auto_increment PRIMARY KEY
, ProductName varchar(25)
, FasciaEta varchar(5)
, AnnoProduzione year
, Id_Categoria int
, foreign key (Id_Categoria) REFERENCES categoria(Id_Categoria));
CREATE TABLE region(
Id_Region int auto_increment primary key
, Regione VARCHAR(25));
CREATE TABLE state(
Id_State int auto_increment primary key
, Stato varchar(25)
, Id_Region INT
, foreign key (Id_Region) references region(Id_Region));
CREATE TABLE sales(
id_Sales int auto_increment primary key
, PrezzoUnitario decimal(10,2)
, Quantita int
, TotalSales decimal(10,2) GENERATED ALWAYS AS (PrezzoUnitario * Quantita) STORED #utilizzando stored il valore viene memorizzato nel database e aggiornato automaticamente
, Id_Prodotto INT
, Id_State INT
, foreign key (Id_Prodotto) REFERENCES product(Id_prodotto)
, foreign key (Id_State) REFERENCES state(Id_State));
INSERT INTO categoria(NomeCategoria) VALUES
('Giocattoli Educativi'),
('Action Figures'),
('Puzzle'),
('Giochi da Tavolo'),
('Bambole'),
('Veicoli Giocattolo'),
('Costruzioni'),
('Giochi Elettronici'),
('Articoli per Bambini'),
('Giochi Esterni');
INSERT INTO product (ProductName, FasciaEta, AnnoProduzione, Id_Categoria) VALUES
('Puzzle Animali', '6-8', 2020, 3),
('Macchinina Racing', '3-5', 2019, 6),
('Doll House', '4-7', 2021, 5),
('Gioco da Tavolo Strategia', '10-12', 2022, 4),
('Costruzioni Base', '3-6', 2023, 7),
('Action Figure Eroe', '8-10', 2020, 2),
('Set Elettronico', '7-12', 2018, 8),
('Gioco Educativo Numeri', '2-4', 2017, 1),
('Palla Gonfiabile', '1-3', 2022, 9),
('Altalena da Giardino', '3-6', 2021, 10);
INSERT INTO region (Regione) VALUES
('Lombardia'),
('Lazio'),
('Campania'),
('Sicilia'),
('Veneto'),
('Piemonte'),
('Emilia-Romagna'),
('Toscana'),
('Puglia'),
('Calabria');
INSERT INTO state (Stato, Id_Region) VALUES
('Milano', 1),
('Roma', 2),
('Napoli', 3),
('Palermo', 4),
('Verona', 5),
('Torino', 6),
('Bologna', 7),
('Firenze', 8),
('Bari', 9),
('Reggio Calabria', 10);
INSERT INTO sales (PrezzoUnitario, Quantita, Id_Prodotto, Id_State) VALUES
(15.50, 10, 1, 1),
(22.00, 5, 2, 2),
(30.00, 8, 3, 3),
(12.75, 15, 4, 4),
(18.40, 7, 5, 5),
(25.00, 9, 6, 6),
(40.00, 4, 7, 7),
(10.00, 20, 8, 8),
(8.50, 12, 9, 9),
(50.00, 3, 10, 10);
#aggiungiamo l'attributo DataVendita per svolgere il secondo esercizio.
ALTER TABLE sales
ADD COLUMN DataVendita DATE;
UPDATE sales SET DataVendita = '2025-01-10' WHERE Id_Sales = 1;
UPDATE sales SET DataVendita = '2025-02-15' WHERE Id_Sales = 2;
UPDATE sales SET DataVendita = '2025-03-20' WHERE Id_Sales = 3;
UPDATE sales SET DataVendita = '2025-04-25' WHERE Id_Sales = 4;
UPDATE sales SET DataVendita = '2025-05-30' WHERE Id_Sales = 5;
UPDATE sales SET DataVendita = '2025-06-04' WHERE Id_Sales = 6;
UPDATE sales SET DataVendita = '2025-06-09' WHERE Id_Sales = 7;
UPDATE sales SET DataVendita = '2025-06-14' WHERE Id_Sales = 8;
UPDATE sales SET DataVendita = '2025-06-19' WHERE Id_Sales = 9;
UPDATE sales SET DataVendita = '2025-06-24' WHERE Id_Sales = 10;
UPDATE sales SET DataVendita = '2024-06-24' WHERE Id_Sales = 10;








