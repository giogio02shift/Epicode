#verifichiamo per ogni tabella che tutte le pk siano univoche.
SELECT count(*) as Totale_righe, count(DISTINCT Id_Categoria) as PK_Univoche
from categoria;
SELECT count(*) as Totale_righe, count(DISTINCT Id_Product) as PK_Univoche
from product;
SELECT count(*) as Totale_righe, count(DISTINCT Id_State) as PK_Univoche
from state;
SELECT count(*) as Totale_righe, count(DISTINCT Id_Sales) as PK_Univoche
from sales;
SELECT count(*) as Totale_righe, count(DISTINCT Id_Region) as PK_Univoche
from region;
#2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT
  CONCAT('DOC', LPAD(s.id_Sales, 5, '0')) AS CodiceDocumento, #lpad ci permette di riempire di zeri il campo finchè non viene raggiunta una lunghezza di 5 caratteri
  s.DataVendita AS Data,
  p.ProductName AS NomeProdotto,
  c.NomeCategoria AS CategoriaProdotto,
  st.Stato AS NomeStato,
  r.Regione AS NomeRegione,
  (DATEDIFF(CURDATE(), s.DataVendita) > 180) AS Oltre180Giorni
FROM sales s
JOIN product p ON s.Id_Prodotto = p.Id_Prodotto
JOIN categoria c ON p.Id_Categoria = c.Id_Categoria
JOIN state st ON s.Id_State = st.Id_State
JOIN region r ON st.Id_Region = r.Id_Region;

#3 Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite (quantità) realizzate nell’ultimo anno censito.
#Nel result set devono comparire solo il codice prodotto (Id_Prodotto) e il totale venduto.

SELECT 
    s.Id_Prodotto,
    SUM(s.Quantita) AS TotaleVenduto
FROM 
    sales s
WHERE 
    YEAR(s.DataVendita) = (
        SELECT YEAR(MAX(DataVendita)) 
        FROM sales
    )
GROUP BY 
    s.Id_Prodotto
HAVING 
    SUM(s.Quantita) > (
        SELECT 
            AVG(quantita_totale)
        FROM (
            SELECT 
                Id_Prodotto,
                SUM(Quantita) AS quantita_totale
            FROM 
                sales
            WHERE 
                YEAR(DataVendita) = (
                    SELECT YEAR(MAX(DataVendita)) 
                    FROM sales
                )
            GROUP BY 
                Id_Prodotto
        ) AS vendite_per_prodotto
    );
    #4	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT 
    p.Id_Prodotto,
    p.ProductName,
    YEAR(s.DataVendita) AS Anno,
    SUM(s.PrezzoUnitario * s.Quantita) AS FatturatoTotale
FROM 
    sales s
JOIN 
    product p ON s.Id_Prodotto = p.Id_Prodotto
GROUP BY 
    p.Id_Prodotto, p.ProductName, YEAR(s.DataVendita)
ORDER BY 
    p.Id_Prodotto, Anno;
#5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
    p.Id_Prodotto,
    p.ProductName,
    YEAR(s.DataVendita) AS Anno,
    SUM(s.PrezzoUnitario * s.Quantita) AS FatturatoTotale
FROM 
    sales s
JOIN 
    product p ON s.Id_Prodotto = p.Id_Prodotto
GROUP BY 
    p.Id_Prodotto, p.ProductName, YEAR(s.DataVendita)
ORDER BY 
    year, FatturatoTotale DESC;
# 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
    c.Id_Categoria,
    c.NomeCategoria,
    SUM(s.Quantita) AS TotaleVenduto
FROM 
    categoria c
INNER JOIN 
    product p ON c.Id_Categoria = p.Id_Categoria
INNER JOIN 
    sales s ON p.Id_Prodotto = s.Id_Prodotto
GROUP BY 
    c.Id_Categoria, c.NomeCategoria
ORDER BY 
    TotaleVenduto DESC
LIMIT 1;
#7) 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti
SELECT ProductName
FROM product P
JOIN sales S ON P.Id_Prodotto=S.Id_Prodotto
WHERE Quantita =0;

SELECT ProductName
FROM product P
JOIN sales S ON P.Id_Prodotto=S.Id_Prodotto
WHERE Quantita is null;

SELECT P.ProductName
FROM product P
LEFT JOIN sales S ON P.Id_Prodotto = S.Id_Prodotto
WHERE S.Id_Prodotto IS NULL;

SELECT P.ProductName
FROM product P
WHERE NOT EXISTS (
    SELECT 1
    FROM sales S
    WHERE S.Id_Prodotto = P.Id_Prodotto
);

#tutti i prodotti sono stati venduti
#8)Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW vista_prodotti_denormalizzata AS
SELECT 
    P.Id_Prodotto AS CodiceProdotto,
    P.ProductName AS NomeProdotto,
    C.NomeCategoria AS NomeCategoria
FROM product P
JOIN categoria C ON P.Id_Categoria = C.Id_Categoria;
#9)Creare una vista per le informazioni geografiche
CREATE VIEW vista_informazioni_geografiche AS
SELECT 
    R.Id_Region,
    R.Regione,
    S.Id_State,
    S.Stato
FROM region R
JOIN state S ON R.Id_Region = S.Id_Region;
